package com.veegam.demo.microservices.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Narsimlu Bommena,  Ness Technologies
 *
 */
@Component
public class MessageService {

    @Value("${name:unknown}")
    private String name;
    
    private Date startDate;
    
    private Date endDate;
    
    private String contentType;

    public String getMessage() {
        return getMessage(name);
    }

    public String getMessage(String name) {
        return  name;
    }

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
    
    

    
    
}
