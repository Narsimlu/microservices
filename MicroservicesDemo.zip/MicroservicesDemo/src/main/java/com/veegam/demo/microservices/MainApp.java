package com.veegam.demo.microservices;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.veegam.demo.microservices.service.MessageService;

/**
 * 
 * @author Narsimlu Bommena, Ness Technologies
 *
 */

@SpringBootApplication
public class MainApp {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(MainApp.class, args);

		MessageService bean = (MessageService) ctx.getBean(MessageService.class);
		bean.getMessage();

		if (args.length > 0) {
			System.out.println("input values are:");
			int i = 0;
			for (String value : args) {
				if (i == 0) {
					bean.setStartDate(convertStringToDate(value));
					System.out.println("Start Date:"+value);
				} else if (i == 1) {
					bean.setEndDate(convertStringToDate(value));
					System.out.println("End Date:"+value);
				} else if (i == 2) {
					bean.setContentType(value);
					System.out.println("Content type value:"+value);
				}
				++i; 
				//System.out.println(value);
				//System.out.println(bean.getMessage(value.toString()));
			}
		} else {
			System.out.println("Not found input arguments. please provide arguments like startdate enddate contenttype");
			System.out.println(bean.getMessage());
		}
	}
	
	private static Date convertStringToDate(String date) {
		SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yy");
		Date testDate = null;
		//String date = "02/30/2012";
		try{
		    testDate = df.parse(date);
		} catch (ParseException e){ 
			System.out.println("invalid format, it should be dd-MMM-yy format");}
		 
		if (df.format(testDate).equals(date)){
		    System.out.println("invalid date!!");
		} else {
		    System.out.println("valid date");
		}
		return testDate;
	}
	
}